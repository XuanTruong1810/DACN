namespace Core.Entities
{
    public class Pigs : BaseEntity
    {
        // public string Name { get; set; }

        // public string? Image { get; set; }

        // public string? Description { get; set; }

        // public int? AreaId { get; set; }

        // public Areas Area { get; set; }
    }
}