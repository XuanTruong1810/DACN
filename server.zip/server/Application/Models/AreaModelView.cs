namespace Application.Models
{
    public class AreaModelView
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}